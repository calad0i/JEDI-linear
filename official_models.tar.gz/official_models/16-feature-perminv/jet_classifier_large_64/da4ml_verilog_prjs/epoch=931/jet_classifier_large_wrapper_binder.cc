#include <cstddef>
#include "binder_util.hh"
#include "Vjet_classifier_large_wrapper.h"

struct jet_classifier_large_wrapper_config {
    static const size_t N_inp = 1024;
    static const size_t N_out = 5;
    static const size_t max_inp_bw = 16;
    static const size_t max_out_bw = 20;
    static const size_t II = 1;
    static const size_t latency = 25;
    typedef Vjet_classifier_large_wrapper dut_t;
};

extern "C" {
bool openmp_enabled() {
    return _openmp;
}

void inference(int32_t *c_inp, int32_t *c_out, size_t n_samples) {
    batch_inference<jet_classifier_large_wrapper_config>(c_inp, c_out, n_samples);
}
}
